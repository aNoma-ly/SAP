CREATE DATABASE  IF NOT EXISTS `project`;
USE `project`;

DROP TABLE IF EXISTS `Staff`;

CREATE TABLE `Staff` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(30) NOT NULL UNIQUE,
  `UserPass` varchar(30) NOT NULL,
  `Pin` varchar(4) NOT NULL default '0000',
  `Perm` varchar(10) NOT NULL,
  `Locked` boolean default false,
  `LockAttempt` int(10) default 3,
  `Email` varchar(30) NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `Staff` VALUES 
	(1,'admin','password',1234,'admin',false, 5,'admin@gmail.com'),
    (2,'user','password',1111,'user',false, 3,'user@gmail.com'),
    (3,'super','password',2222,'super',false, 3,'admin@gmail.com');

select * from Staff;
select Perm from Staff where UserName='admin' and UserPass='password';