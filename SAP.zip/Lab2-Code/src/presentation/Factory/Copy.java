package presentation.Factory;

import java.io.*;

public class Copy extends fileProp{
    public Copy(String fileName) {
        setFileName(fileName);
        setFilePath(System.getProperty("user.dir") + "/" + getFileName());
        try {

            BufferedReader brc = new BufferedReader(
                    new FileReader(getFilePath()));

            BufferedWriter bwc = new BufferedWriter(
                    new FileWriter(fileName + "Copy.txt"));

            String read;
            while ((read = brc.readLine()) != null) {
                bwc.write(read + "\n");
            }
            brc.close();
            bwc.close();

            setResponse("File successfully copied");

        } catch (IOException ex) {
            setResponse("Not a valid filename." + "\n" + "File copy failed");
        }
    }
}
