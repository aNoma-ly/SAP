package presentation.Factory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import presentation.Template.*;

public class Write extends fileProp{
    public  Write(String fileName) {
        setFileName(fileName);
        setFilePath(System.getProperty("user.dir") + "/" + getFileName());
        String content = template();

        if (content != null) {
            try {
                BufferedWriter bw = new BufferedWriter(
                        //this format will change for windows:
                        new FileWriter(getFilePath()));

                bw.write(content);


                bw.close();

                setResponse("File written succesfully");
            } catch (IOException ex) {
                setResponse("File not written succesfully");
            }
        }else{
            setResponse("File does not contain content");
        }
    }
    public static String template(){

        String content = null;

        Scanner scanner = new Scanner(System.in);

        System.out.println("\n" +"Please choose your order");
        System.out.println("\n" +"1" + "\t" + "Original Burger");
        System.out.println("\n" +"2" + "\t" + "Vegetarian Burger");
        System.out.println("\n" +"3" + "\t" + "Original Burger Meal");
        System.out.println("\n" +"4" + "\t" + "Vegetarian Burger Meal");

        Integer Option = scanner.nextInt();

        if(Option != null) {
            if(Option == 1) {
                Order order = new OGBurger();
                order.makeOrder();
                content = order.getOrder();
                return content;
            }
            else if(Option == 2) {
                Order order = new VGBurger();
                order.makeOrder();
                content = order.getOrder();
                return content;
            }
            else if(Option == 3) {
                Order order = new OGMeal();
                order.makeOrder();
                content = order.getOrder();
                return content;
            }
            else if(Option == 4) {
                Order order = new VGMeal();
                order.makeOrder();
                content = order.getOrder();
                return content;
            }
            else{
                System.out.println("Please enter a valid option");
                return content;
            }
        }
        else{
            System.out.println("Please enter a value");
            return content;
        }
    }
}


