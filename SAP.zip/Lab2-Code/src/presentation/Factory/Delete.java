package presentation.Factory;

import java.io.*;

public class Delete extends fileProp {
    public Delete(String fileName){

        setFileName(fileName);
        setFilePath(System.getProperty("user.dir") + "/" + getFileName());

            try {
                File f = new File(getFilePath());
                if(f.delete())
                {
                    setResponse("File successfully deleted");
                }
                else
                {
                    setResponse("Not a valid filename." + "\n" + "File not deleted successfully");
                }
            } catch (Exception ex) {
                //insecure coding
                ex.printStackTrace();
                //secure coding alternative
                // setResponse("Not a valid filename." + "\n" + "File not deleted successfully");
            }

    }

}
