package presentation.Factory;

import java.io.*;

public class Read extends fileProp{
    public Read(String fileName){
        setFileName(fileName);
        setFilePath(System.getProperty("user.dir") + "/" + getFileName());

        try {
            BufferedReader br = new BufferedReader(
                    new FileReader(getFilePath()));
            String read;

            while((read = br.readLine()) != null){
                setResponse(read + "\n");
            }
            br.close();

            setResponse("\n" + "File read succesfully");
        }
        catch(IOException ex){
            setResponse("Not a valid filename." + "\n" + "File not read successfully");
        }
    }
}
