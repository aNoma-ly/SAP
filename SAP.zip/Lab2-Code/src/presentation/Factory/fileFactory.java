package presentation.Factory;

public class fileFactory {
    public fileProp makeFileProp(String Operation, String fileName){ //String Operation
        String response;

        if (fileName==""){
            return null;
        }
        else if (Operation.equals("W")){
            return new Write(fileName);
        }
        else if(Operation.equals("R")){
            return new Read(fileName);
        }
        else if(Operation.equals("C")){
            return new Copy(fileName);
        }
        else if(Operation.equals("D")){
            return new Delete(fileName);
        }
        else{
            return null;
        }
    }
}
