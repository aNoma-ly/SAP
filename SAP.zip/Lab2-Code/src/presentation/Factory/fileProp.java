package presentation.Factory;

public abstract class fileProp {
    private String filePath;
    private String fileName;
    private String response = "";


    public void setResponse(String newResponse) {
        response = response + newResponse;
    }

    public void setFileName(String newfileName) {
        fileName = newfileName + ".txt";
    }

    public String getFileName() {
        return fileName;
    }

    public void setFilePath(String newFilePath) {
        filePath = newFilePath;

    }

    public String getFilePath() {
        return filePath;
    }

    public void outputResponse(){
        System.out.println(response);
    }
}
