package presentation;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import presentation.Factory.fileFactory;
import presentation.Factory.fileProp;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class SuperController implements Initializable {
    private static String buttonSelection="";
    @FXML
    BorderPane superBorderPane;


    public void btnBackAction(){
        goToLoginPage();
        closeWindow();

    }

    public void btnOrderAction(){
        buttonSelection = "W";
        factory();

    }
    public void accessOrderAction(){

        buttonSelection = "R";
        factory();

    }

    public void deleteOrderAction(){
        Scanner scanner = new Scanner(System.in);
        Boolean repeat = true;

       while(repeat == true){
        System.out.println("Do you wish to make a copy of a file before deleting it? (Y/N)");
        String Choice = scanner.nextLine();
            if(Choice.equalsIgnoreCase("Y")) {
                buttonSelection = "C";
                factory();
                repeat = false;
            }
            else if(Choice.equalsIgnoreCase("N")){
                repeat = false;
            }
            else{
                System.out.println("Please enter Y or N");
            }
        }
        buttonSelection = "D";
        factory();
    }

    public void copyOrderAction(){
        buttonSelection = "C";
        factory();


    }
    public void goToLoginPage(){

        try{
            Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root));
            registerStage.show();

        } catch(Exception ex){
            ex.printStackTrace();
            ex.getCause();
        }

    }
    public void closeWindow(){
        Stage stage = (Stage) superBorderPane.getScene().getWindow();
        stage.close();
    }

    public static void factory(){
        fileFactory FileFactory = new fileFactory();

        fileProp theFile = null;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Please enter the filename");
        String Operation = buttonSelection;
        if(scanner.hasNextLine()) {

            String fileName = scanner.nextLine();

            theFile = FileFactory.makeFileProp(Operation, fileName);

        }
        if(theFile==null){
            System.out.println("Retry, please enter the filename");
        }
        else {
            outputFileContent(theFile);
        }
    }
    public static void outputFileContent(fileProp aFile){
        aFile.outputResponse();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
