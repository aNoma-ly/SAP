package presentation.Template;

public class VGMeal extends Order {
    @Override
    void addMeat() {}

    @Override
    void addVeggieMeat() {
        setOrder("\n" +"Add veggie patty");
    }

    @Override
    void addSoda() {
        setOrder("\n" +"Add Soda");
    }

    @Override
    void addFries() {
        setOrder("\n" +"Add Fries");
    }
}
