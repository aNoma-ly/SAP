package presentation.Template;

import java.util.Random;

public abstract class Order {
    Random rand = new Random();
    String order ="";
    Integer orderNumber;

    public Integer getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber() {
        orderNumber = rand.nextInt(1000);
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String Step) {
        order = order + Step;
    }



    public final void makeOrder(){
        OrderID();

        Bun();

        if(Meat()){
            addMeat();
        }

        if(veggieMeat()){
            addVeggieMeat();
        }

        Cheese();

        Sauce();

        if(Soda()){
            addSoda();
        }
        if(Fries()){
            addFries();
        }
        Toast();
    }

    abstract void addMeat();
    abstract void addVeggieMeat();
    abstract void addSoda();
    abstract void addFries();


    boolean Meat(){return true;}
    boolean veggieMeat(){return true;}
    boolean Soda(){return true;}
    boolean Fries(){return true;}


    public void OrderID(){
        setOrderNumber();
        setOrder("\n" + "Order number: " + getOrderNumber());
    }

    private void Bun() {
        setOrder("\n" + "Add bun");
    }

    private void Cheese() {
        setOrder("\n" + "Add cheese");
    }

    private void Sauce() {
        setOrder("\n" + "Add sauce");
    }

    private void Toast() {
        setOrder("\n" + "Toast burger");
    }
}
