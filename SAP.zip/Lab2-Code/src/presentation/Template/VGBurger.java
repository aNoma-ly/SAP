package presentation.Template;

public class VGBurger extends Order{
    @Override
    void addMeat() {}

    @Override
    void addVeggieMeat() {
        setOrder("\n" +"Add veggie patty");
    }

    @Override
    void addSoda() {}

    @Override
    void addFries() {}
}
