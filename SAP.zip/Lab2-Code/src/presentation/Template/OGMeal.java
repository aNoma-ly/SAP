package presentation.Template;

public class OGMeal extends Order{
    @Override
    void addMeat() {
        setOrder("\n" +"Add beef patty");
    }

    @Override
    void addVeggieMeat() {}

    @Override
    void addSoda() {
        setOrder("\n" +"Add Soda");
    }

    @Override
    void addFries() {
        setOrder("\n" +"Add Fries");
    }
}
