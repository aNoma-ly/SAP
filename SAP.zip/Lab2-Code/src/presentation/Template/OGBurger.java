package presentation.Template;

public class OGBurger extends Order {
    @Override
    void addMeat() {
        setOrder("\n" +"Add beef meat patty");
    }

    @Override
    void addVeggieMeat() {}

    @Override
    void addSoda() {}

    @Override
    void addFries() {}
}
