package presentation;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import presentation.Factory.*;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;

public class UserController implements Initializable {
    @FXML
    BorderPane userBorderPane;


    public void btnBackAction(){
        goToLoginPage();
        closeWindow();

    }

    public void btnOrderAction(){
        factory();
    }
    public void goToLoginPage(){

        try{
            Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage registerStage = new Stage();
            registerStage.initStyle(StageStyle.UNDECORATED);
            registerStage.setScene(new Scene(root));
            registerStage.show();

        } catch(Exception ex){
            ex.printStackTrace();
            ex.getCause();
        }

    }
    public void closeWindow(){
        Stage stage = (Stage) userBorderPane.getScene().getWindow();
        stage.close();
    }

    public static void factory(){
        fileFactory FileFactory = new fileFactory();

        fileProp theFile = null;

        Scanner scanner = new Scanner(System.in);

        String Operation = "W";

        System.out.println("Please enter filename");

        if(scanner.hasNextLine()) {

            String fileName = scanner.nextLine();

            theFile = FileFactory.makeFileProp(Operation, fileName);

        }
        if(theFile==null){
            System.out.println("Retry, please enter filename");
        }
        else {
            outputFileContent(theFile);
        }
    }

    public static void outputFileContent(fileProp aFile){
        aFile.outputResponse();
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
