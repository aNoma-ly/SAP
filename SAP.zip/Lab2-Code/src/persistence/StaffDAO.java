package persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class StaffDAO {


    public static boolean validateUser(String name, String password) {
        boolean status = false;
        try {
            Connection con = persistence.DBMySQL.getInstance().getConnection();
            String select = "select * from Staff where UserName= '" + name + "' and UserPass='" + password + "'";
            Statement selectStatement = con.createStatement();
            ResultSet rs = selectStatement.executeQuery(select);
            status = rs.next();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;
    }

    public static String getPerm(String name, String password) {
        String perm = "dave";
        System.out.println("Name "+name);
        try {
            Connection con = persistence.DBMySQL.getInstance().getConnection();
            //String select = "select * from Staff where UserName= '" + name + "' and UserPass='" + password + "'";
           String select = "select * from Staff where UserName='"+name+"' and UserPass='"+password+"'";
            System.out.println(select);
           // String select = "select * from Staff where UserName="+name;
            Statement selectStatement = con.createStatement();
            ResultSet rs = selectStatement.executeQuery(select);
            while (rs.next()) {
                System.out.println(rs.getString("UserName"));
                System.out.println(rs.getString("Perm"));
                perm = rs.getString("Perm");
                System.out.println(perm);

            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
            perm = "Exception";
        }
        return perm;

    }


    public static boolean checkIfExists(String UserName) {
        boolean status = false;
        try {
            Connection con = persistence.DBMySQL.getInstance().getConnection();
            String select = "select * from Staff where UserName= '" + UserName + "'";
            Statement selectStatement = con.createStatement();
            ResultSet rs = selectStatement.executeQuery(select);
            status = rs.next();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;

    }


    public static int AddUser(String userName, String userPass, String userPin, String userEmail) {
        int status = 0;
        try {
            String perm = "User";
            Connection con = persistence.DBMySQL.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("insert into Staff(UserName, UserPass,Perm, Pin, Email) values(?,?,?,?,?)");
            ps.setString(1, userName);
            ps.setString(2, userPass);
            ps.setString(3, perm);
            ps.setString(4, userPin);
            ps.setString(5, userEmail);
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return status;

    }
}
