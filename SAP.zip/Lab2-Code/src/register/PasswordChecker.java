package register;

import java.text.DecimalFormat;

public class PasswordChecker {

    String password;
    String confirmPassword;
    int pin;
    String message;
    Boolean valid;

    public PasswordChecker(String password, String confirmPassword, String pin) {

        this.password = password;
        this.confirmPassword = confirmPassword;
        this.valid = false;
        this.pin = Integer.parseInt(pin);
        this.message = "";

    }


    public boolean isValidPassword(){
     return this.message.equals("OK");
    }

    public String validatePasswordPin(){

         /*
                OWASP old password validation checks
                Password minimum length 6
                Password must contain capital letter
                Password must contain small letter
                Password must contain a number
                password must contain a special character
         */

        boolean passwordMatch = this.password.equals(this.confirmPassword);
        boolean pinLength = (int) (Math.log10(this.pin)+1) == 4;
        boolean isCorrectLength     = true;
        boolean hasCapitalLetter    = true;
        boolean hasLowerLetter      = true;
        boolean hasNumber           = true;
        boolean hasSpecialCharacter = true;

        if(!passwordMatch){
            this.message = "Passwords do not match";
        }else if(!pinLength){
            this.message = "Pin should contain four numbers";
        }else if(!isCorrectLength){
            this.message = "Password Should be at least 6 characters";
        }else if(!hasCapitalLetter){
            this.message = "Password Should contain a Capital Letter";
        }else if(!hasLowerLetter){
            this.message = "Password Should contain a Lower Case Letter";
        }else if(!hasNumber){
            this.message = "Password Should contain a Number";
        }else if(!hasSpecialCharacter){
            this.message = "Password Should contain a Special Character";
        }else{
            this.message = "OK";
        }
      return this.message;

    }

}
